#!/bin/bash
set -ex

tumor_bam=tumor.bam
normal_bam=normal.bam
region_bed=region.bed
reference=ref.fa
reference_dict=ref.dict #can be obtained using picard CreateSequenceDictionary
random_SNV=random_sSNV.bed
random_INDEL=random_sINDEL.bed
num_threads=28
work=work
mindepth=5
maxdepth=10000
minmutreads=2

tumor_bam=$(realpath ${tumor_bam})
normal_bam=$(realpath ${normal_bam})
region_bed=$(realpath ${region_bed})
random_SNV=$(realpath ${random_SNV})
random_INDEL=$(realpath ${random_INDEL})
reference=$(realpath ${reference})
reference_dict=$(realpath ${reference_dict})
mkdir -p ${work}
work=$(realpath ${work})

docker run -v /:/mnt -u ${UID} --rm --memory 14g --workdir=/mnt/${work} lethalfang/bamsurgeon:1.0.0-4 \
/usr/local/bamsurgeon/bin/addsnv.py \
--snvfrac 0.1 --mutfrac 0.5 --coverdiff 0.9 --procs ${num_threads} \
--varfile /mnt/${random_SNV} \
--bamfile /mnt/${tumor_bam} \
--reference /mnt/${reference} \
--outbam /mnt/${work}/unsorted.snvs.added.bam \
--mindepth ${mindepth} \
--maxdepth ${maxdepth} \
--minmutreads ${minmutreads} \
--seed 2018 \
--picardjar /usr/local/picard-tools-1.131/picard.jar \
--ignoresnps --force --tagreads \
--aligner mem

docker run -v /:/mnt -u ${UID} --rm lethalfang/bamsurgeon:1.0.0-4 \
/usr/local/bamsurgeon/scripts/makevcf.py \
/mnt/${work}/addsnv_logs_unsorted.snvs.added.bam \
| docker run -v /:/mnt -u ${UID} --rm -i lethalfang/bedtools:2.26.0 \
bedtools sort -header -faidx /mnt/${reference}.fai \
> ${work}/synthetic_snvs.vcf

docker run -v /:/mnt -u ${UID} --rm lethalfang/samtools:1.3.1 \
samtools sort -m 4G --reference /mnt/${reference} -o /mnt/${work}/snvs.added.bam /mnt/${work}/unsorted.snvs.added.bam
docker run -v /:/mnt -u ${UID} --rm lethalfang/samtools:1.3.1 samtools index /mnt/${work}/snvs.added.bam

rm ${work}/unsorted.snvs.added.bam

docker run -v /:/mnt -u ${UID} --rm --memory 14g --workdir=/mnt/${work} lethalfang/bamsurgeon:1.0.0-4 \
/usr/local/bamsurgeon/bin/addindel.py \
--snvfrac 0.1 --mutfrac 0.5 --coverdiff 0.9 --procs ${num_threads} \
--varfile /mnt/${random_INDEL} \
--bamfile /mnt/${work}/snvs.added.bam \
--reference /mnt/${reference} \
--outbam /mnt/${work}/unsorted.snvs.indels.added.bam \
--picardjar /usr/local/picard-tools-1.131/picard.jar \
--mindepth ${mindepth} \
--maxdepth ${maxdepth} \
--minmutreads ${minmutreads} \
--seed 2018 \
--tagreads --force \
--aligner mem

docker run -v /:/mnt -u ${UID} --rm lethalfang/bamsurgeon:1.0.0-4 \
/usr/local/bamsurgeon/scripts/makevcf_indels.py \
/mnt/${work}/addindel_logs_unsorted.snvs.indels.added.bam /mnt/${reference} \
| docker run -v /:/mnt -u ${UID} --rm -i lethalfang/bedtools:2.26.0 \
bedtools sort -header -faidx /mnt/${reference}.fai \
> ${work}/synthetic_indels.vcf

docker run --rm -v /:/mnt -u ${UID} lethalfang/somaticseq:latest \
java -jar /opt/GATK/GenomeAnalysisTK.jar -T LeftAlignAndTrimVariants \
-R /mnt/${reference} \
--variant /mnt/${work}/synthetic_indels.vcf \
| egrep -v '^[0-9]+ variants|^INFO' > ${work}/synthetic_indels.leftAlign.vcf

docker run -v /:/mnt -u ${UID} --rm lethalfang/samtools:1.3.1 \
samtools sort -m 4G --reference /mnt/${reference} -o /mnt/${work}/snvs.indels.added.bam /mnt/${work}/unsorted.snvs.indels.added.bam
docker run -v /:/mnt -u ${UID} --rm lethalfang/samtools:1.3.1 samtools index /mnt/${work}/snvs.indels.added.bam

rm ${work}/unsorted.snvs.indels.added.bam

docker run --rm -v /:/mnt -u ${UID} --memory 10g broadinstitute/gatk3:3.7-0 java -Xmx9g -jar GenomeAnalysisTK.jar \
-T RealignerTargetCreator \
-R /mnt/${reference} \
-I /mnt/${work}/snvs.indels.added.bam \
-I /mnt/${normal_bam} \
-L /mnt/${region_bed} \
-o /mnt/${work}/T.N.intervals

docker run --rm -v /:/mnt -u ${UID} --memory 10g -w /mnt/${work} broadinstitute/gatk3:3.7-0 \
java -Xmx9g -jar /usr/GenomeAnalysisTK.jar \
-T IndelRealigner \
-R /mnt/${reference} \
-I /mnt/${work}/snvs.indels.added.bam \
-I /mnt/${normal_bam} \
-targetIntervals /mnt/${work}/T.N.intervals \
-dt NONE --maxReadsForConsensuses 150000 --maxReadsInMemory 500000 --maxReadsForRealignment 2000000 \
-nWayOut .JointRealigned.bam


normal_bam_name=${work}/"$(basename ${normal_bam%.*})"
mv ${normal_bam_name}.JointRealigned.bai ${normal_bam_name}.JointRealigned.bam.bai
mv ${work}/snvs.indels.added.JointRealigned.bai ${work}/snvs.indels.added.JointRealigned.bam.bai

mv ${normal_bam_name}.JointRealigned.bam     ${work}/syntheticNormal.bam
mv ${normal_bam_name}.JointRealigned.bam.bai ${work}/syntheticNormal.bam.bai

mv ${work}/snvs.indels.added.JointRealigned.bam      ${work}/syntheticTumor.bam
mv ${work}/snvs.indels.added.JointRealigned.bam.bai  ${work}/syntheticTumor.bam.bai

docker run -v /:/mnt -u ${UID} --memory 2g --rm lethalfang/vcftools:0.1.14 bash -c \
"vcf-concat \
/mnt/${work}/synthetic_snvs.vcf \
/mnt/${work}/synthetic_indels.leftAlign.vcf > /mnt/${work}/synthetic_truth_unsorted.vcf"

docker run -v /:/mnt -u ${UID} --rm lethalfang/bamsurgeon:1.0.0-4 bash -c \
"vcfsorter.pl /mnt/${reference_dict} /mnt/${work}/synthetic_truth_unsorted.vcf \
> /mnt/${work}/synthetic_truth.vcf "

for file in ${work}/snvs.indels.added.bam \
			${work}/snvs.indels.added.bam.bai \
			${work}/snvs.added.bam \
			${work}/snvs.added.bam.bai ${work}/synthetic_truth_unsorted.vcf \
			${work}/synthetic_snvs.vcf ${work}/snvs.indels.added.bam.bai \
			${work}/synthetic_indels.leftAlign.vcf ${work}/synthetic_indels.vcf.idx ${work}/synthetic_indels.vcf 
do
    rm -fv $file
done

rm -rf ${work}/add*