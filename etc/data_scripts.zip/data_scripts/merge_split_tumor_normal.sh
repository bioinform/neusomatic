#!/bin/bash
set -ex

tumor_bam=tumor.bam
normal_bam=normal.bam
region_bed=region.bed
work=work


tumor_bam=$(realpath ${tumor_bam})
normal_bam=$(realpath ${normal_bam})
region_bed=$(realpath ${region_bed})
mkdir -p ${work}
work=$(realpath ${work})


docker run -v /:/mnt -u ${UID} --memory 6g --rm lethalfang/bamsurgeon:1.0.0-4 \
java -Xmx6g -jar /usr/local/picard-tools-1.131/picard.jar MergeSamFiles \
I=/mnt/${normal_bam} \
I=/mnt/${tumor_bam} \
ASSUME_SORTED=true \
CREATE_INDEX=true \
O=/mnt/${work}/TNMerged.bam

mv ${work}/TNMerged.bai ${work}/TNMerged.bam.bai


docker run -v /:/mnt -u ${UID} --rm --memory 8g lethalfang/bamsurgeon:1.0.0-4 \
/usr/local/bamsurgeon/scripts/sortedBamSplit.py \
--bam /mnt/${work}/TNMerged.bam \
--proportion 0.5 \
--downsample 1 \
--pick1 /mnt/${work}/Designated.Normal.bam \
--pick2 /mnt/${work}/Designated.Tumor.bam \
--seed 2018

docker run -v /:/mnt -u ${UID} --rm --memory 8g lethalfang/samtools:1.3.1 samtools index /mnt/${work}/Designated.Normal.bam
docker run -v /:/mnt -u ${UID} --rm --memory 8g lethalfang/samtools:1.3.1 samtools index /mnt/${work}/Designated.Tumor.bam


for file in ${work}/TNMerged.bam  ${work}/TNMerged.bam.bai
do
    rm -fv $file
done
