#!/usr/bin/env bash

set -ex 

longislnd_sample=/path/to/longislnd_0.9.5.binary/sample.py #available at https://github.com/bioinform/longislnd
longislnd_simulate=/path/to/longislnd_0.9.5.binary/simulate.py
longislnd_jar=/path/to/longislnd_0.9.5.binary/sample.py/longislnd_0.9.5.binary/target/LongISLND-0.9.jar
bam=HG002.bam
reference=ref.fa

model_dir=model

germline=HG002.vcf.gz
somatic=PacBio_somatic_chr1_chr22.vcf
vcfs="$germline $somatic"

simulation=work_varsim

mkdir -pv $simulation

cp $germline $simulation/germline.vcf.gz && tabix $simulation/germline.vcf.gz && germline=$simulation/germline.vcf.gz
bgzip -c $somatic > $simulation/somatic.vcf.gz && tabix $simulation/somatic.vcf.gz && somatic=$simulation/somatic.vcf.gz

coverage=200
regions=regions.bed
varsim=/path/to/varsim/0.8.3/varsim_multi.py #available at https://github.com/bioinform/varsim
sample=tumor
python $varsim --reference $reference \
--out_dir $simulation/$sample --simulator longislnd \
--simulator_executable $longislnd_simulate \
--disable_rand_vcf --disable_rand_dgv --seed 4 \
--simulator_options " --model_dir $model_dir --read_type bax --jvm_opt \"-Xms80g -Xmx80g\" " \
--total_coverage $coverage --vcfs $germline $somatic --lift_ref --samples $sample --regions $regions

sample=normal
python $varsim --reference $reference --out_dir $simulation/$sample \
--simulator longislnd --simulator_executable $longislnd_simulate \
--disable_rand_vcf --disable_rand_dgv --seed 5 \
--simulator_options " --model_dir $model_dir --read_type bax --jvm_opt \"-Xms80g -Xmx80g\" " \
--total_coverage $coverage --vcfs $germline --lift_ref --samples $sample --regions $regions

chmod -R g+w $simulation
