import os
import shutil

import pybedtools

high_confidence_bed = "h.bed"
tumor_germline_vcf = "t.vcf"
normal_germline_vcf = "n.vcf"
work = "work"
ref="ref.fa"

if not os.path.exists(work):
    os.mkdir(work)

somatic_mix_truth = "{}/somatic_mix_truth.vcf".format(work)
somatic_mix_target_region = "{}/somatic_mix_target_regions.bed".format(work)


hc_bed = pybedtools.BedTool(high_confidence_bed)

tumor_bed = pybedtools.BedTool(tumor_germline_vcf).intersect(hc_bed, u=True).each(
    lambda x: pybedtools.Interval(
        x[0], int(x[1]), int(x[1]) + len(x[3]), x[3], x[4], x[5], otherfields=x[6:])).saveas()
normal_bed = pybedtools.BedTool(normal_germline_vcf).intersect(hc_bed, u=True).each(lambda x: pybedtools.Interval(
    x[0], int(x[1]), int(x[1]) + len(x[3]), x[3], x[4], x[5], otherfields=x[6:])).saveas()


min_var_distance_TN = 5
min_var_distance_TT = 300

tumor_bed_0 = tumor_bed.window(normal_bed, w=min_var_distance_TN, v=True)

truth_P = tumor_bed_0.filter(lambda x: len(
    set(x[9].split(":")[0].replace("|","/").split("/")) - set(["0", "1"])) == 0).saveas()

ignore_vcf_P = tumor_bed.window(normal_bed, w=min_var_distance_TN, u=True).cat(
    tumor_bed_0.filter(lambda x: len(
        set(x[9].split(":")[0].replace("|","/").split("/")) - set(["0", "1"])) > 0).saveas(),
    postmerge=False).sort()

target_region_p = hc_bed.subtract(ignore_vcf_P.slop(
    g="{}.fai".format(ref), b=5))

truth_P = truth_P.intersect(target_region_p)

truth_P.window(normal_bed, w=min_var_distance_TN).count()

truth_P.saveas(somatic_mix_truth)

target_region_p.saveas(somatic_mix_target_region)