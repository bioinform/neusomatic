import os
import shutil

import pysam
import pybedtools
import numpy as np

tumor_bam = "tumor.bam"
normal_bam = "normal.bam"
high_confidence_bed = "h.bed"
tumor_germline_vcf = "t.vcf"
normal_germline_vcf = "n.vcf"
work = "work"
ref="ref.fa"

if not os.path.exists(work):
    os.mkdir(work)

somatic_spike_target_region = "{}/somatic_spike_target_regions.bed".format(work)
somatic_spike_bam = "{}/somatic_spike.bam".format(work)
somatic_spike_truth = "{}/somatic_spike_truth.vcf".format(work)


hc_bed = pybedtools.BedTool(high_confidence_bed)

tumor_bed = pybedtools.BedTool(tumor_germline_vcf).intersect(hc_bed, u=True).each(
    lambda x: pybedtools.Interval(
        x[0], int(x[1]), int(x[1]) + len(x[3]), x[3], x[4], x[5], otherfields=x[6:])).saveas()
normal_bed = pybedtools.BedTool(normal_germline_vcf).intersect(hc_bed, u=True).each(lambda x: pybedtools.Interval(
    x[0], int(x[1]), int(x[1]) + len(x[3]), x[3], x[4], x[5], otherfields=x[6:])).saveas()


min_var_distance_TN = 5
min_var_distance_TT = 300

tumor_bed_0 = tumor_bed.window(normal_bed, w=min_var_distance_TN, v=True)

truth_P = tumor_bed_0.filter(lambda x: len(
    set(x[9].split(":")[0].split("|")) - set(["0", "1"])) == 0).saveas()


ignore_vcf_P = tumor_bed.window(normal_bed, w=min_var_distance_TN, u=True).cat(
    tumor_bed_0.filter(lambda x: len(
        set(x[9].split(":")[0].split("|")) - set(["0", "1"])) > 0).saveas(),
    postmerge=False).sort()

target_region_p = hc_bed.subtract(ignore_vcf_P.slop(
    g="{}.fai".format(ref), b=5))

truth_P = truth_P.intersect(target_region_p)

truth_P.window(normal_bed, w=min_var_distance_TN).count()

target_region_p.saveas(somatic_spike_target_region)

gts = map(lambda x: x[9].split(":")[0], truth_P)

tumor_bed_1 = tumor_bed_0.window(tumor_bed_0, w=min_var_distance_TT).filter(
    lambda x: x[1] != x[11]).cut([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]).saveas()

tumor_bed_2 = tumor_bed_0.window(tumor_bed_1, w=0, v=True).filter(
    lambda x: len(set(x[9].split(":")[0].split("|")) - set(["0", "1"])) == 0).saveas()


ignore_vcf_v = tumor_bed.window(normal_bed, w=min_var_distance_TN).filter(
    lambda x: not((x[1] == x[11]) and (x[2] == x[12]) and (x[3] == x[13]) and (x[4] == x[14])
                  and (x[9].split(":")[0] == x[19].split(":")[0]))
).saveas().cat(tumor_bed_1, postmerge=False).cat(
    tumor_bed_0.filter(lambda x: len(
        set(x[9].split(":")[0].split("|")) - set(["0", "1"])) > 0).saveas(),
    postmerge=False
).sort().merge(d=-1, c=[4, 5, 6, 7, 8, 9, 10], o="first").saveas()


gts = map(lambda x: x[9].split(":")[0], tumor_bed_2)
candidates = []
for i, x in enumerate(tumor_bed_2):
    x[5] = i
    candidates.append(x)
candidate_tumor_variants = pybedtools.BedTool(candidates)
candidate_tumor_variants.saveas()

bad_ids = []
with pysam.AlignmentFile(tumor_bam) as samfile:
    for region_ in ignore_vcf_v:
        for record in samfile.fetch(region_[0], int(region_[1]) - 1, int(region_[2])):
            bad_ids.append(record.qname)
bad_ids = set(bad_ids)

rid_dict = {}
with pysam.AlignmentFile(tumor_bam) as samfile:
    for region_ in candidate_tumor_variants:
        for record in samfile.fetch(region_[0], int(region_[1]) - 1, int(region_[2])):
            qname = record.qname.split("/")[0]
            if qname not in rid_dict:
                rid_dict[qname] = set([])
            rid_dict[qname].add(region_[5])


cid_2_rid = {}
bad_cids = []
for rid in rid_dict:
    cids = map(int, list(rid_dict[rid]))
    if len(set(cids)) > 1:
        bad_cids.extend(cids)
        continue
    if rid in bad_ids:
        bad_cids.extend(cids)
        continue
    for cid in set(cids):
        if cid not in cid_2_rid:
            cid_2_rid[cid] = []
        cid_2_rid[cid].append(rid)
bad_cids = set(bad_cids)
for cid in set(bad_cids):
    if cid in cid_2_rid:
        del cid_2_rid[cid]


good_candidates = []
for i in cid_2_rid:
    good_candidates.append(candidates[i])
good_candidates = pybedtools.BedTool(good_candidates)


rid_dict_normal = {}
with pysam.AlignmentFile(normal_bam) as samfile:
    for region_ in good_candidates:
        for record in samfile.fetch(region_[0], int(region_[1]) - 1, int(region_[2])):
            qname = record.qname.split("/")[0]
            if qname not in rid_dict_normal:
                rid_dict_normal[qname] = set([])
            rid_dict_normal[qname].add(region_[5])


cid_2_rid_n = {}
bad_cids_n = []
for rid in rid_dict_normal:
    cids = map(int, list(rid_dict_normal[rid]))
    if len(set(cids)) > 1:
        bad_cids_n.extend(cids)
        continue
    for cid in set(cids):
        if cid not in cid_2_rid_n:
            cid_2_rid_n[cid] = []
        cid_2_rid_n[cid].append(rid)
bad_cids_n = set(bad_cids_n)
for cid in set(bad_cids_n):
    if cid in cid_2_rid_n:
        del cid_2_rid_n[cid]


rid_2_i = {}
i_2_rid = {}
i = 0
for cid in cid_2_rid:
    for rid in cid_2_rid[cid]:
        if rid not in rid_2_i:
            rid_2_i[rid] = i
            i_2_rid[i] = rid
            i += 1


ridn_2_i = {}
i_2_ridn = {}
i = 0
for cid in cid_2_rid_n:
    for rid in cid_2_rid_n[cid]:
        if rid not in ridn_2_i:
            ridn_2_i[rid] = i
            i_2_ridn[i] = rid
            i += 1

for cid in cid_2_rid:
    cid_2_rid[cid] = map(lambda x: rid_2_i[x], cid_2_rid[cid])

for cid in cid_2_rid_n:
    cid_2_rid_n[cid] = map(lambda x: ridn_2_i[x], cid_2_rid_n[cid])


vafs = [0.5, 0.5, 0.5, 0.5] #[0.05, 0.1, 0.2, 0.3]


c = 0
spiked_t_reads = np.zeros((len(rid_2_i),))
removed_n_reads = np.zeros((len(ridn_2_i),))
variants = {}
done = []


k = 0
cids = sorted(set(cid_2_rid.keys()) & set(cid_2_rid_n.keys()))
for cid in set(cids) - set(done):
    if cid not in done:
        depth_t = len(cid_2_rid[cid])
        depth_n = len(cid_2_rid_n[cid])
        vaf = vafs[np.random.randint(4)]
        depth_rpl = max(1, np.random.binomial(depth_n, vaf))
        if 0 < depth_rpl <= depth_t:
            spiked_t_reads[np.random.permutation(
                cid_2_rid[cid])[0:depth_rpl]] = 1
            removed_n_reads[np.random.permutation(
                cid_2_rid_n[cid])[0:depth_rpl]] = 1
            variants[cid] = [depth_t, depth_n,
                             depth_rpl, vaf, candidates[cid][9]]
        if depth_rpl == 0:
            c += 1
        done.append(cid)
    k += 1

spiked_t_reads = map(lambda x: i_2_rid[x], np.nonzero(spiked_t_reads)[0])
removed_n_reads = map(lambda x: i_2_ridn[x], np.nonzero(removed_n_reads)[0])

spiked_t_reads = set(spiked_t_reads)
removed_n_reads = set(removed_n_reads)

print len(spiked_t_reads)
print len(removed_n_reads)

b1 = 0
b2 = 0
c1 = 0
c2 = 0
somatic_spike_bam_unsorted = "{}/somatic_spike_unsorted.bam".format(work)

with pysam.AlignmentFile(tumor_bam) as tumor_bam_f:
    with pysam.AlignmentFile(normal_bam) as normal_bam_f:
        rg_normal=normal_bam_f.header["RG"]
        for i in range(len(rg_normal)):
            rg_normal[i]["SM"]="spike_tumor"
        rg_tumor=tumor_bam_f.header["RG"]
        for i in range(len(rg_tumor)):
            rg_tumor[i]["SM"]="spike_tumor"
        header=dict(tumor_bam_f.header)
        header["RG"]=rg_tumor+rg_normal
        with pysam.AlignmentFile(somatic_spike_bam_unsorted, "wb", header=header) as virtual_bam:
            for read in tumor_bam_f:
                c1 += 1
                if read.qname in spiked_t_reads:
                    virtual_bam.write(read)
                    b1 += 1
            for read in normal_bam_f:
                c2 += 1
                if read.qname not in removed_n_reads:
                    virtual_bam.write(read)
                else:
                    b2 += 1


with open(somatic_spike_truth, "w") as vcf_f:
    vcf_f.write("##fileformat=VCFv4.2\n")
    vcf_f.write("#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\n")
    for cid, var in variants.iteritems():
        chrom, pos, _, ref, alt = candidates[cid][0:5]
        td, nd, sd, vaf, gt = var
        raf = float(vaf)
        if len(set(gt.replace("|", "/").split("/"))) == 2:
            raf /= 2
        vcf_f.write("\t".join([chrom, pos, ".", ref, alt, ".",
                               "TD={};ND={};SD={};RAF={};AF={}".format(
                                   td, nd, sd, raf, vaf),
                               "GT:TD:ND:SD:RAF:AF",
                               "{}:{}:{}:{}:{}:{}".format(gt, td, nd, sd, raf, vaf)]) + "\n")

pysam.sort("-o",somatic_spike_bam,somatic_spike_bam_unsorted)
shutil.rmtree(somatic_spike_bam_unsorted)
