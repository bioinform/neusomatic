#!/usr/bin/bash
set -ex

tumor_bam=tumor.bam
normal_bam=normal.bam
work=work
mkdir -p ${work}
tumor_rate=0.05
normal_rate=0.95
# mixed_sm_tag="mixed_tumor" #Use mixed_tumor if the output is mixed tumor pair
mixed_sm_tag="mixed_normal" #Use mixed_normal if the output is mixed normal pair
num_threads=10
reference=/sc1/groups/bfx-red/data/datainsights/references/human_g1k_v37_decoy/human_g1k_v37_decoy.fasta

tumor_bam=$(realpath ${tumor_bam})
normal_bam=$(realpath ${normal_bam})
work=$(realpath ${work})
reference=$(realpath ${reference})

tumor_sm_tag=$(docker run -v /:/mnt -u ${UID} --rm lethalfang/samtools:1.7 \
			  samtools view -H /mnt/${tumor_bam}|grep "^@RG"|awk -v FS="SM:" '{print $2}'|cut -f 1|sort|uniq)
normal_sm_tag=$(docker run -v /:/mnt -u ${UID} --rm lethalfang/samtools:1.7 \
			  samtools view -H /mnt/${normal_bam}|grep "^@RG"|awk -v FS="SM:" '{print $2}'|cut -f 1|sort|uniq)


#Downsample tumor
docker run --rm -v /:/mnt -u $UID lethalfang/picard:2.10.10 \
java -Xmx20G -jar /opt/picard.jar DownsampleSam \
I=/mnt/${tumor_bam} \
O=/mnt/${work}/tumor_${tumor_rate}.bam \
P=${tumor_rate} \
CREATE_INDEX=true 

#Downsample normal
docker run --rm -v /:/mnt -u $UID lethalfang/picard:2.10.10 \
java -Xmx20G -jar /opt/picard.jar DownsampleSam \
I=/mnt/${normal_bam} \
O=/mnt/${work}/normal_${normal_rate}.bam \
P=${normal_rate} \
CREATE_INDEX=true 

#Mix tumor and normal
docker run --rm -v /:/mnt -u $UID lethalfang/picard:2.10.10 \
java -Xmx16g -jar /opt/picard.jar MergeSamFiles \
I=/mnt/${work}/normal_${normal_rate}.bam \
I=/mnt/${work}/tumor_${tumor_rate}.bam \
O=/mnt/${work}/mixture_T_${tumor_rate}_N_${normal_rate}.neads_reheader.bam \
SORT_ORDER=coordinate \
USE_THREADING=true \
CREATE_INDEX=true 

#Fix header for SM tag
docker run -v /:/mnt -u ${UID} --rm lethalfang/samtools:1.7 \
samtools view -H /mnt/${work}/mixture_T_${tumor_rate}_N_${normal_rate}.neads_reheader.bam > \
${work}/mixture_T_${tumor_rate}_N_${normal_rate}.fixed_header.txt 

for sm in ${tumor_sm_tag} ${normal_sm_tag}
do
    sed "s/SM:${sm}/SM:${mixed_sm_tag}/g" -i ${work}/mixture_T_${tumor_rate}_N_${normal_rate}.fixed_header.txt  
done


#Replace new header
docker run --rm -v /:/mnt -u $UID lethalfang/picard:2.10.10 \
java -Xmx16g -jar /opt/picard.jar ReplaceSamHeader \
I=/mnt/${work}/mixture_T_${tumor_rate}_N_${normal_rate}.neads_reheader.bam \
HEADER=/mnt/${work}/mixture_T_${tumor_rate}_N_${normal_rate}.fixed_header.txt \
O=/mnt/${work}/mixture_T_${tumor_rate}_N_${normal_rate}.bam  \
CREATE_INDEX=true 

mv ${work}/mixture_T_${tumor_rate}_N_${normal_rate}.bai ${work}/mixture_T_${tumor_rate}_N_${normal_rate}.bam.bai 
rm ${work}/mixture_T_${tumor_rate}_N_${normal_rate}.neads_reheader.*
rm ${work}/mixture_T_${tumor_rate}_N_${normal_rate}.fixed_header.txt

docker run -v /:/mnt -u ${UID} --rm lethalfang/samtools:1.7 \
samtools calmd -@ ${num_threads} \
-b /mnt/${work}/mixture_T_${tumor_rate}_N_${normal_rate}.bam /mnt/${reference} \
 > ${work}/mixture_T_${tumor_rate}_N_${normal_rate}.md.bam 
docker run -v /:/mnt -u ${UID} --rm lethalfang/samtools:1.7 \
samtools index /mnt/${work}/mixture_T_${tumor_rate}_N_${normal_rate}.md.bam

rm ${work}/mixture_T_${tumor_rate}_N_${normal_rate}.ba*
rm ${work}/tumor_${tumor_rate}.ba*
rm ${work}/normal_${normal_rate}.ba*



