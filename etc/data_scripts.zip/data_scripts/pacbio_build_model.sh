#!/usr/bin/env bash

longislnd_sample=/path/to/longislnd_0.9.5.binary/sample.py #available at https://github.com/bioinform/longislnd
longislnd_jar=/path/to/longislnd_0.9.5.binary/target/LongISLND-0.9.jar
bam=HG002.bam
reference=ref.fa

model_dir=model
work=work

cd ${work}
python $longislnd_sample \
--input_suffix fastq.bam \
--read_type fastq \
--model_dir $model_dir \
--min_length 30 \
--reference $reference \
--flank 3 
