# Instructions to reproduce NeuSomatic Synthetic datasets

The random variants/sites used in the paper for the following samples are provided in `resources` folder.

## Platinum mixture samples
##### 1. Prepare input bams
* Download NA12878 200x fastq files (Used as virtual tumor)
* Download NA12877200x fastq files (Used as normal)
* Downsample all NA12878 fastqs by 25% to get 50x data as follows:
 ```seqtk sample -s1 fastq.gz 0.25| gzip > fastq_s1.gz```
* Prepare two independent 25% downsamples of NA12877. One for normal, one to use for mixing. 
 ```seqtk sample -s1 fastq.gz 0.25| gzip > fastq_s1.gz```
 ```seqtk sample -s2 fastq.gz 0.25| gzip > fastq_s2.gz```
* Align and merge fastqs to get `na12878_50x.bam` and two `na12877_50x_s1.bam` and `na12877_50x_s2.bam`.

##### 2. Prepare sample mixture
Use `prepare_sample_mixture.sh` with the following settings to get 70T-30N virtual tumor mixture:
```
tumor="na12878_50x_s1.bam"
normal="na12877_50x_s1.bam"
tumor_rate=0.7
normal_rate=0.3
mixed_sm_tag="mixed_tumor"
```
Similarly, you can obtain 50T-50N and 25T-75N virtual tumor mixture. You can also obtain 5T-95N 95% pure normal as follows:
```
tumor="na12878_50x_s1.bam"
normal="na12877_50x_s2.bam"
tumor_rate=0.05
normal_rate=0.95
mixed_sm_tag="mixed_normal"
```
##### 3. Obtain ground truth and target region
Use `get_germline_mix_truth.py`, with germline VCFs and high-confidence BED file found from ftp://ftp-trace.ncbi.nlm.nih.gov/giab/ftp/release/NA12878_HG001/NISTv3.3.2/ .
```
tumor="na12878_50x_s1.bam"
normal="na12877_50x_s1.bam"
```

## Platinum tumor spike sample
Use the above 50x alignment files in `get_germline_spike_truth_and_bam.py` along with germline VCFs and high-confidence BED file.
```
tumor="na12878_50x_s1.bam"
normal="na12877_50x_s1.bam"
```

## DREAM challenge mixture samples
##### 1. Prepare augmented tumor with more truth somatic variant for training
* Generate random sites using `generate_random_site.sh` with
`num_snvs=100000` and `num_indels=100000`.
* Spike random variants into the tumor sample using `sim_spike_bams.sh` with generated `random_sSNV.bed` and `random_sINDEL.bed` in the previous step, and use `minmutreads=2`.
##### 2. Prepare sample mixture
Use `prepare_sample_mixture.sh` as shown before you can get 70T-30N, 50T-50N, 25T-75N virtual tumor mixture as well as 5T-95N 95% pure normal.


## Whole-Exome mixture samples
##### 1. Prepare input bams
* Downsample 200x HG004 bam by 50% to get 100x data as follows:
 ```java -Xmx16g -jar picard.jar DownsampleSam  I=HG004.bam O=HG004_s1_100x.bam P=0.5 RANDOM_SEED=1 CREATE_INDEX=true```
* Prepare two independent 50% downsamples of HG003. One for normal, one to use for mixing. 
 ```java -Xmx16g -jar picard.jar DownsampleSam  I=HG002.bam O=HG003_s1_100x.bam P=0.5 RANDOM_SEED=1 CREATE_INDEX=true```
 ```java -Xmx16g -jar picard.jar DownsampleSam  I=HG002.bam O=HG003_s2_100x.bam P=0.5 RANDOM_SEED=2 CREATE_INDEX=true```

##### 2. Prepare sample mixture
Use `prepare_sample_mixture.sh` as before to get 70T-30N, 50T-50N, 25T-75N virtual tumor mixture as well as 5T-95N 95% pure normal.

##### 3. Obtain ground truth and target region
Use `get_germline_mix_truth.py`, with germline VCFs and high-confidence BED file found from ftp://ftp-trace.ncbi.nlm.nih.gov/giab/ftp/release/AshkenazimTrio/HG002_NA24385_son/NISTv3.3.2/.


## TCGA-AZ-4315 simulated tumor-normal pair
We used tumor/normal pair of TCGA-AZ-4315 as the training sample.
* Merge the real tumor/normal pairs and split them to two halfs using `merge_split_tumor_normal.sh`.
* Generate random sites using `generate_random_site.sh` with
`num_snvs=100000` and `num_indels=10000`.
* Spike random variants into the synthetic tumor sample obtained above using `sim_spike_bams.sh` with generated `random_sSNV.bed` and `random_sINDEL.bed` in the previous step, and use `minmutreads=5`.
 
## PacBio simulation
1. Use `pacbio_build_model.sh` to build a model based on real HG002 PacBio data.
2. Use `pacbio_sim.sh` to simulate tumor and normal samples using germline VCF obtained from ftp://ftp-trace.ncbi.nlm.nih.gov/giab/ftp/release/AshkenazimTrio/HG002_NA24385_son/NISTv3.3.2/, and the random somatic VCF at `resources/PacBio_somatic_chr1_chr22.vcf.gz`.
3. Align fastqs.
4. Downsample and mix synthetic tumor and normal samples at different ratios to obtain 50T-50N, 30T-70N, and 20T-80N ratios using `prepare_sample_mixture.sh` as before.


