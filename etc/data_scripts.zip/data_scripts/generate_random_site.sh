#!/bin/bash
set -ex

region_bed=region.bed
reference=ref.fa
reference_dict=ref.dict #can be obtained using picard CreateSequenceDictionary
num_snvs=1000
num_indels=1000
work=work
vafbeta1=3
vafbeta2=7
minvaf=0
maxvaf=1

region_bed=$(realpath ${region_bed})
reference=$(realpath ${reference})
mkdir -p ${work}
work=$(realpath ${work})

docker run -v /:/mnt -u ${UID} --rm lethalfang/bamsurgeon:1.0.0-4 bash -c \
"/usr/local/bamsurgeon/scripts/randomsites.py \
--genome /mnt/${reference} \
--seed 2018 \
--bed /mnt/${region_bed} \
--numpicks ${num_snvs} \
--minvaf ${minvaf} \
--maxvaf ${maxvaf} \
--vafbeta1 ${vafbeta1} \
--vafbeta2 ${vafbeta2} \
--avoidN snv \
| bedtools sort -header -faidx /mnt/${reference}.fai > /mnt/${work}/random_sSNV.bed"

docker run -v /:/mnt -u ${UID} --rm lethalfang/bamsurgeon:1.0.0-4 bash -c \
"/usr/local/bamsurgeon/scripts/randomsites.py \
--genome /mnt/${reference} \
--seed 2018 \
--bed /mnt/${region_bed} \
--numpicks ${num_indels} \
--minvaf ${minvaf} \
--maxvaf ${maxvaf} \
--vafbeta1 ${vafbeta1} \
--vafbeta2 ${vafbeta2} \
--avoidN indel --maxlen 18  \
| vcfsorter.pl /mnt/${reference_dict} - > /mnt/${work}/random_sINDEL.bed"


